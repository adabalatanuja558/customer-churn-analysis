
# 📉 Customer Churn Analysis

**Objective**: Predict customer churn and understand what factors influence it.

## 📊 Tools Used
- Python (Pandas, NumPy, Matplotlib, Seaborn)
- Tableau

## 📁 Folders
- `/data` → Dataset
- `/notebooks` → Analysis
- `/images` → Visuals or Tableau Dashboards

## 📌 Summary
This project uses synthetic telecom data to analyze churn behavior.
